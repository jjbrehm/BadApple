library(testthat)
library(BadApple)

test_check("BadApple")
